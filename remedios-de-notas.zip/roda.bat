@echo off 
npm start